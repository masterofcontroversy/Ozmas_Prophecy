# [\[Paladin-Custom\] \[U\] Gold Knight by Nuramon](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FMounted%20-%20Cavs%2C%20Paladins%2C%20Rangers%2F%5BPaladin-Custom%5D%20%5BU%5D%20Gold%20Knight%20by%20Nuramon%2F8.%20Unarmed)

## Unarmed

| Still | Animation |
| :---: | :-------: |
| ![Unarmed still](./Unarmed_000.png) | ![Unarmed](./Unarmed.gif) |

## Credit

Made by Nuramon.
