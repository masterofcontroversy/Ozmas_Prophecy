# [\[FE8 Ephraim-Custom\] \[M\] T2 Heavy Infantry by Nuramon](./) [![Download](https://img.shields.io/badge/Download--red?style=social&logo=github)](https://minhaskamal.github.io/DownGit/#/home?url=https://github.com/Klokinator/FE-Repo/tree/main/Battle%20Animations%2FLords%20-%20Vanilla%20and%20Custom%2F%5BFE8%20Ephraim-Custom%5D%20%5BM%5D%20T2%20Heavy%20Infantry%20by%20Nuramon%2F3.%20Axe)

## Axe

| Still | Animation |
| :---: | :-------: |
| ![Axe still](./Axe_000.png) | ![Axe](./Axe.gif) |

## Credit


